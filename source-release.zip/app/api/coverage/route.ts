import {coverage} from '../../../lib/market/repository';
import {json,error} from '../../../lib/market/http.mjs';
export async function GET(){try{return json(await coverage());}catch(e){return error(e);}}

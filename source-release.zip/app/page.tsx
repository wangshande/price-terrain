import {redirect} from "next/navigation";
export default function Page(){redirect("/atlas/index.html");}
